
<?php


error_reporting(0);
 session_start();
 $conn=mysqli_connect("localhost","root","","electrokleen");

$query1="SELECT * from notice";
$notice=$conn->query($query1);
$fromdatee=$_POST['fromdate'];
$todatee=$_POST['todate'];
$limit=$_POST['limit'];
$query2="SELECT s_no,machine_name,oil_level from full where datee between '".$fromdatee."' and '".$todatee."'  and oil_level>".$limit."";
$result1=$conn->query($query2);

?>
<!DOCTYPE html>
<html lang="en">
<head>
       <meta charset="utf-8">
      <meta http-equiv="X-UA-Compatible" content="IE=edge">
      <meta name="viewport" content="width=device-width, initial-scale=1">
      <title>Electrokleen</title>
      <!-- Favicon and touch icons -->
      <link rel="shortcut icon" href="assets/dist/img/ico/favicon.png" type="image/x-icon">
      <!-- Start Global Mandatory Style
         =====================================================================-->
      <!-- jquery-ui css -->
      <link href="assets/plugins/jquery-ui-1.12.1/jquery-ui.min.css" rel="stylesheet" type="text/css"/>
      <!-- Bootstrap -->
      <link href="assets/bootstrap/css/bootstrap.min.css" rel="stylesheet" type="text/css"/>
      <!-- Bootstrap rtl -->
      <!--<link href="assets/bootstrap-rtl/bootstrap-rtl.min.css" rel="stylesheet" type="text/css"/>-->
      <!-- Lobipanel css -->
      <link href="assets/plugins/lobipanel/lobipanel.min.css" rel="stylesheet" type="text/css"/>
      <!-- Pace css -->
      <link href="assets/plugins/pace/flash.css" rel="stylesheet" type="text/css"/>
      <!-- Font Awesome -->
      <link href="assets/font-awesome/css/font-awesome.min.css" rel="stylesheet" type="text/css"/>
      <!-- Pe-icon -->
      <link href="assets/pe-icon-7-stroke/css/pe-icon-7-stroke.css" rel="stylesheet" type="text/css"/>
      <!-- Themify icons -->
      <link href="assets/themify-icons/themify-icons.css" rel="stylesheet" type="text/css"/>
      <!-- End Global Mandatory Style
         =====================================================================-->
      <!-- Start Theme Layout Style
         =====================================================================-->
      <!-- Theme style -->
      <link href="assets/dist/css/stylecrm.css" rel="stylesheet" type="text/css"/>
      <!-- Theme style rtl -->
      <!--<link href="assets/dist/css/stylecrm-rtl.css" rel="stylesheet" type="text/css"/>-->
      <!-- End Theme Layout Style
     
         =====================================================================-->
   </head>
   <body class="hold-transition sidebar-mini">
   <!--preloader-->
      <div id="preloader">
         <div id="status"></div>
      </div>
      <!-- Site wrapper -->
      <div class="wrapper">
         <header class="main-header">
            <a href="dashboard.php" class="logo">
               <!-- Logo -->
               <span class="logo-lg">
               <img src="assets/dist/img/logo.jpg" alt="">
               </span>
            </a>
            <!-- Header Navbar -->
            <nav class="navbar navbar-static-top">
               <a href="#" class="sidebar-toggle" data-toggle="offcanvas" role="button">
                  <!-- Sidebar toggle button-->
                  <span class="sr-only">Toggle navigation</span>
                  <span class="pe-7s-angle-left-circle"></span>
               </a>
               <div class="navbar-custom-menu">
                  <ul class="nav navbar-nav">
                     <!-- Orders -->
                     
                     <!-- Messages -->
                     
                     <!-- Notifications -->
                     <li class="dropdown notifications-menu">
                        <a href="#" class="dropdown-toggle" data-toggle="dropdown">
                        <i class="pe-7s-bell"></i>
                        <span class="label label-warning">7</span>
                        </a>
                        <ul class="dropdown-menu">
                           <li>
                              <ul class="menu">
                               <?php

                                 while($row=$notice->fetch_assoc())
                                 {
                               
                                echo  "<li>";
                                 echo  "<a href=\"#\" class=\"border-gray\">";
                                   echo  "<i class=\"fa fa-dot-circle-o color-red\"></i>'".$row['message']."' </a>";
                                echo  "</li>";
                             }

                                 ?>
                              </ul>
                           </li>
                        </ul>
                     </li>
                     <!-- Tasks -->
                     <!-- Help -->
                     <!-- user -->
                     <li class="dropdown dropdown-user">
                        <a href="#" class="dropdown-toggle" data-toggle="dropdown">
                        <img src="assets/dist/img/avatar5.png" class="img-circle" width="45" height="45" alt="user"></a>
                        <ul class="dropdown-menu" >
                           
                           <li><a href="index.html">
                              <i class="fa fa-sign-out"></i> Signout</a>
                           </li>
                        </ul>
                     </li>
                  </ul>
               </div>
            </nav>
         </header>
         <!-- =============================================== -->
         <!-- Left side column. contains the sidebar -->
         <aside class="main-sidebar">
            <!-- sidebar -->
            <div class="sidebar">
               <!-- sidebar menu -->
               <ul class="sidebar-menu">
                  <li class="active">
                     <a href="dashboard.php"><i class="fa fa-tachometer"></i><span>Dashboard</span>
                     <span class="pull-right-container">
                     </span>
                     </a>
                  </li>
                  <li class="treeview">
                     <a href="#">
                     <i class="fa fa-list"></i><span>Add Consumption Details</span>
                     <span class="pull-right-container">
                     <i class="fa fa-angle-left pull-right"></i>
                     </span>
                     </a>
                     <ul class="treeview-menu">
                        <li><a href="add.php">Add Entry</a></li>
                        <li><a href="update.php">Update Entry</a></li>
                       <!--  <li><a href="delete.html">Delete Entry</a></li> -->
                     </ul>
                  </li>
                  
                  <li class="treeview">
                     <a href="#">
                     <i class="fa fa-bell"></i><span>Attendance</span>
                     <span class="pull-right-container">
                     <i class="fa fa-angle-left pull-right"></i>
                     </span>
                     </a>
                     <ul class="treeview-menu">
                        <li><a href="mark_at.php">Mark Attendance</a></li>
                        
                        <li><a href="at_report.php">Attendance Report</a></li>
                     </ul>
                  </li>
                 <li class="treeview">
                     <a href="#">
                     <i class="fa fa-bitbucket-square"></i><span>Stock</span>
                     <span class="pull-right-container">
                     <i class="fa fa-angle-left pull-right"></i>
                     </span>
                     </a>
                     <ul class="treeview-menu">
                        <li><a href="stockcost.php">Update Cost Details</a></li>
                        <li><a href="opening_stock.php">opening Stock</a></li>
                       

                        <li><a href="move_order.php">Move Order</a></li>
                        <li><a href="physical.php">physical_stock</a></li>
                         <li><a href="stock_report.php"> stock Report</a></li>
                     </ul>
                  </li>
                  <li class="treeview">
                     <a href="#">
                     <i class="fa fa-bar-chart"></i><span>Report</span>
                     <span class="pull-right-container">
                     <i class="fa fa-angle-left pull-right"></i>
                     </span>
                     </a>
                     <ul class="treeview-menu">
                         <li><a href='daily.php'><span>Daliy Report</span></a></li>
                          <li><a href='monthly.php'><span>Monthly Report</span></a></li>
                          <li><a href='weekly.php'><span>weekly Report</span></a></li>
                        
                             <li><a href='oilt.php'><span>Oil type Wise Report</span></a></li>
                           <li><a href='machine.php'><span>Machinary Report</span></a></li>
                          <li><a href='cost.php'><span>Cost Report</span></a></li>

                     </ul>
                  </li>
                  <li>
                     <a href="company.php">
                     <i class="fa fa-home"></i> <span>Companies</span>
                     <span class="pull-right-container">
                     </span>
                     </a>
                  </li>
                  <li>
                     <a href="machine_details.php">
                     <i class="glyphicon glyphicon-print"></i> <span>Manage Machine</span>
                     <span class="pull-right-container">
                     </span>
                     </a>
                  </li>
                  <li>
                     <a href="oil_details.php">
                     <i class="glyphicon glyphicon-tint"></i> <span>Manage Oil</span>
                     <span class="pull-right-container">
                     </span>
                     </a>
                  </li>
                  <li>
                     <a href="high.php">
                     <i class="fa fa-gear"></i> <span>Track High Consumption</span>
                     <span class="pull-right-container">
                     </span>
                     </a>
                  </li>
                  <li>
                     <a href="target.php">
                     <i class="fa fa-stop-circle"></i> <span>Set Targer</span>
                     <span class="pull-right-container">
                     </span>
                     </a>
                  </li>
                  

                  <li>
                     <a href="updatetemplevel.php">
                     <i class="fa fa-tachometer"></i> <span>Update Temperature/level</span>
                     <span class="pull-right-container">
                     </span>
                     </a>
                  </li>
               </ul>
            </div>
            <!-- /.sidebar -->
       </aside>
         <!-- =============================================== -->
        <!-- Content Wrapper. Contains page content -->
         <div class="content-wrapper">
            <!-- Content Header (Page header) -->
            <section class="content-header">
               
               <div class="header-title">
                  <h1>Track High Consumption Macine</h1>
                                 </div>
            </section>
            <!-- Main content -->
            <section class="content">
               <div class="row">
                  <div class="col-md-12">
                     <div class="panel lobidisable panel-bd">
                        <div class="panel-heading">
                           <div class="panel-title">
                              <h4>Limit</h4>
                           </div>
                        </div>
                        <div class="panel-body">
                           <form class="col-md-6 col-md-offset-3" action="high.php" method="post">
                               <div class="form-group">
                                 <label>From Date</label>
                                 <div class="form-group">
                                    <input name="fromdate" type="date" class="form-control years" placeholder="">
                                 </div>
                              </div>
                              
                              <div class="form-group">
                                 <label>To Date</label>
                                 <div class="form-group">
                                    <input name="todate" type="date" class="form-control years" placeholder="">
                                 </div>
                              </div>
                               <div class="form-group">
                                        <label>Enter Limit</label>
                                        <input type="number" class="form-control" name="limit" placeholder="" required>
                                     </div>
                              <div class="col-md-12 text-center">
                                 <button type="submit"  name ="track" class="btn btn-add">Track</button>
                              </div>
                           </form>
                        </div>
                     </div>
                  </div>
               </div>
                <?php
				
				if(isset($_POST['fromdate']))
				{
				?>
				<div class="row">
                   <div class="col-sm-12">
                      <div class="panel panel-bd lobidrag">
                         <div class="panel-heading">
                            <div class="btn-group" id="buttonexport">
                               <a href="#">
                                  <h4>update</h4>
                               </a>
                            </div>
                         </div>
                         <div class="panel-body">
                         <!-- Plugin content:powerpoint,txt,pdf,png,word,xl -->
                            <div class="btn-group">
                               <button class="btn btn-exp btn-sm dropdown-toggle" data-toggle="dropdown"><i class="fa fa-bars"></i> Export Table Data</button>
                               <ul class="dropdown-menu exp-drop" role="menu">
                                  <li>
                                     <a href="#" onclick="$('#fulltable').tableExport({type:'json',escape:'false'});"> 
                                     <img src="assets/dist/img/json.png" width="24" alt="logo"> JSON</a>
                                  </li>
                                  <li>
                                     <a href="#" onclick="$('#fulltable').tableExport({type:'json',escape:'false',ignoreColumn:'[2,3]'});">
                                     <img src="assets/dist/img/json.png" width="24" alt="logo"> JSON (ignoreColumn)</a>
                                  </li>
                                  <li><a href="#" onclick="$('#fulltable').tableExport({type:'json',escape:'true'});">
                                     <img src="assets/dist/img/json.png" width="24" alt="logo"> JSON (with Escape)</a>
                                  </li>
                                  <li class="divider"></li>
                                  <li><a href="#" onclick="$('#fulltable').tableExport({type:'xml',escape:'false'});">
                                     <img src="assets/dist/img/xml.png" width="24" alt="logo"> XML</a>
                                  </li>
                                  <li><a href="#" onclick="$('#fulltable').tableExport({type:'sql'});"> 
                                     <img src="assets/dist/img/sql.png" width="24" alt="logo"> SQL</a>
                                  </li>
                                  <li class="divider"></li>
                                  <li>
                                     <a href="#" onclick="$('#fulltable').tableExport({type:'csv',escape:'false'});"> 
                                     <img src="assets/dist/img/csv.png" width="24" alt="logo"> CSV</a>
                                  </li>
                                  <li>
                                     <a href="#" onclick="$('#fulltable').tableExport({type:'txt',escape:'false'});"> 
                                     <img src="assets/dist/img/txt.png" width="24" alt="logo"> TXT</a>
                                  </li>
                                  <li class="divider"></li>
                                  <li>
                                     <a href="#" onclick="$('#fulltable').tableExport({type:'excel',escape:'false'});"> 
                                     <img src="assets/dist/img/xls.png" width="24" alt="logo"> XLS</a>
                                  </li>
                                  <li>
                                     <a href="#" onclick="$('#fulltable').tableExport({type:'doc',escape:'false'});">
                                     <img src="assets/dist/img/word.png" width="24" alt="logo"> Word</a>
                                  </li>
                                  <li>
                                     <a href="#" onclick="$('#fulltable').tableExport({type:'powerpoint',escape:'false'});"> 
                                     <img src="assets/dist/img/ppt.png" width="24" alt="logo"> PowerPoint</a>
                                  </li>
                                  <li class="divider"></li>
                                  <li>
                                     <a href="#" onclick="$('#fulltable').tableExport({type:'png',escape:'false'});"> 
                                     <img src="assets/dist/img/png.png" width="24" alt="logo"> PNG</a>
                                  </li>
                                  <li>
                                     <a href="#" onclick="$('#fulltable').tableExport({type:'pdf',pdfFontSize:'7',escape:'false'});"> 
                                     <img src="assets/dist/img/pdf.png" width="24" alt="logo"> PDF</a>
                                  </li>
                               </ul>
                            </div>
                            <!-- ./Plugin content:powerpoint,txt,pdf,png,word,xl -->
                                  <div class="table-responsive">
                                     <table id="fulltable" class="table table-bordered table-striped table-hover">
                                        <thead>
                                           <tr class="info">
                                              <th>S_No</th>
                                              
                                              <th>Machine Name</th>
                                             
                                              <th>Oil level</th>
                                             
                                           </tr>
                                        </thead>
                                        <tbody>
                                          <?php
                                          $temp=0;
                                          while($row=$result1->fetch_assoc())
                                          {
                                             $temp++;
                                                      
                                            echo "<tr>";
                                              echo " <td>".$temp."</td>";
                                              echo " <td>".$row['machine_name']."</td>";
                                              echo " <td>".$row['oil_level']."</td>";
                                             
                                         }
                                           ?>
                                           <!-- <tr>
                                              <td>1</td>
                                              <td>05/06/2017</td>
                                              <td>Nakamura1</td>
                                              <td>C bay</td>
                                              <td>Hydrolic</td>
                                              <td>VGA32</td>
                                              <td>200
                                              </td>
                                              <td>20</td>
                                              <td>5000$</td>
                                              <td>
                                                 <button type="button" class="btn btn-add btn-sm" data-toggle="modal" data-target="#customer1"><i class="fa fa-pencil"></i></button>
                                                 <button type="button" class="btn btn-danger btn-sm" data-toggle="modal" data-target="#customer2"><i class="fa fa-trash-o"></i> </button>
                                              </td>
                                           </tr> <tr>
                                              <td>1</td>
                                              <td>05/06/2017</td>
                                              <td>Nakamura1</td>
                                              <td>C bay</td>
                                              <td>Hydrolic</td>
                                              <td>VGA32</td>
                                              <td>200
                                              </td>
                                              <td>20</td>
                                              <td>5000$</td>
                                              <td>
                                                 <button type="button" class="btn btn-add btn-sm" data-toggle="modal" data-target="#customer1"><i class="fa fa-pencil"></i></button>
                                                 <button type="button" class="btn btn-danger btn-sm" data-toggle="modal" data-target="#customer2"><i class="fa fa-trash-o"></i> </button>
                                              </td>
                                           </tr> -->
                                           <!-- <tr>
                                              <td>INV 524</td>
                                              <td>Maria Gusikowski</td>
                                              <td>$ 1,544.00</td>
                                              <td>05/06/2017</td>
                                              <td>05/02/2017</td>
                                              <td>Onetime</td>
                                              <td><span class="label-danger label label-default" >Inactive</span>
                                              </td>
                                              <td>
                                                 <button type="button" class="btn btn-add btn-sm" data-toggle="modal" data-target="#customer1"><i class="fa fa-pencil"></i></button>
                                                 <button type="button" class="btn btn-danger btn-sm" data-toggle="modal" data-target="#customer2"><i class="fa fa-trash-o"></i> </button>
                                              </td>
                                           </tr>
                                           <tr>
                                              <td>INV 475</td>
                                              <td>Leo Messi</td>
                                              <td>$ 1,846.00</td>
                                              <td>05/06/2017</td>
                                              <td>05/02/2017</td>
                                              <td>Onetime</td>
                                              <td><span class="label-custom label label-default" >active</span>
                                              </td>
                                              <td>
                                                 <button type="button" class="btn btn-add btn-sm" data-toggle="modal" data-target="#customer1"><i class="fa fa-pencil"></i></button>
                                                 <button type="button" class="btn btn-danger btn-sm" data-toggle="modal" data-target="#customer2"><i class="fa fa-trash-o"></i> </button>
                                              </td>
                                           </tr>
                                           <tr>
                                              <td>INV 975</td>
                                              <td>Andre pirlo</td>
                                              <td>$ 1,954.00</td>
                                              <td>05/06/2017</td>
                                              <td>05/02/2017</td>
                                              <td>Onetime</td>
                                              <td><span class="label-custom label label-default" >active</span>
                                              </td>
                                              <td>
                                                 <button type="button" class="btn btn-add btn-sm" data-toggle="modal" data-target="#customer1"><i class="fa fa-pencil"></i></button>
                                                 <button type="button" class="btn btn-danger btn-sm" data-toggle="modal" data-target="#customer2"><i class="fa fa-trash-o"></i> </button>
                                              </td>
                                           </tr> -->
                                        </tbody>
                                     </table>
                                  </div>
                               </div>
                            </div>
                         </div>
                      </div>
					  <?php
				}
				?>
                      <!-- customer Modal1 -->
                      <div class="modal fade" id="edit" tabindex="-1" role="dialog" aria-hidden="true">
                         <div class="modal-dialog">
                            <div class="modal-content">
                               <div class="modal-header modal-header-primary">
                                  <button type="button" class="close" data-dismiss="modal" aria-hidden="true">×</button>
                                  <h3><i class="fa fa-user m-r-5"></i> Edit Entry</h3>
                               </div>
                               <div class="modal-body">
                                  <div class="row">
                                     <div class="col-md-12">
                                        <form class="form-horizontal" action="update.php" method="post">
                                           <fieldset>
                                              <!-- Text input-->
                                              <div class="form-group">
                                        <label>Date</label>
                                        <div class=" input-group date form_date">
                                           <input id='minMaxExample' type="text" class="form-control years" name="datee"><span class="input-group-addon"><a href="#"><i class="fa fa-calendar"></i></a></span>
                                        </div>
                                     </div>
                                     <div class="form-group">
                                        <label>Machine Name</label>
                                        <select class="form-control" name="machine_name">
                                           <option>nakamura1</option>
                                           <option>nakamura2</option>
                                           <option>nakamura3</option>
                                           <option>nakamura4</option>
                                      
                                          
                                          
                                     </select>
                                     </div>
                                     <div class="form-group">
                                        <label>Enter line</label>
                                        <input type="text" class="form-control" name="line" placeholder="" required>
                                     </div>
                                   <div class="form-group">
                                      <label>Choose Oil Type</label>
                                      <select class="form-control" name="oil_type">
                                         <option>Lube</option>
                                         <option>Hydrallic</option>
                                        
                                        
                                   </select>
                                   </div>
                                   <div class="form-group">
                                      <label>Choose Oil Grade</label>
                                      <select class="form-control" name="oil_grade">
                                         <option>vga32</option>
                                         <option>vga46</option>
                                         <option>vga68</option>
                                         <option>vga156</option>
                                         <option>vga320</option>
                                        
                                        
                                   </select>
                                   </div>
                                  
                                   <div class="form-group">
                                      <label>Oil Consumption</label>
                                      <input type="text" class="form-control" name="oil_level" placeholder="In Liters" required>
                                   </div>
                                  <div class="col-md-12 form-group user-form-group">
                                                 <div class="pull-right">
                                                    <button type="button" class="btn btn-danger btn-sm">Cancel</button>
                                                    <button type="submit" name="update" class="btn btn-add btn-sm">Save</button>
                                                 </div>
                                              </div>
                                           </fieldset>
                                        </form>
                                     </div>
                                  </div>
                               </div>
                               <div class="modal-footer">
                                  <button type="button" class="btn btn-danger pull-left" data-dismiss="modal">Close</button>
                               </div>
                            </div>
                            <!-- /.modal-content -->
                         </div>
                         <!-- /.modal-dialog -->
                      </div>
                      <!-- /.modal -->
                      <!-- Modal -->   
                      <!-- Customer Modal2 -->
                      <div class="modal fade" id="delete" tabindex="-1" role="dialog" aria-hidden="true">
                         <div class="modal-dialog">
                            <div class="modal-content">
                               <div class="modal-header modal-header-primary">
                                  <button type="button" class="close" data-dismiss="modal" aria-hidden="true">×</button>
                                  <h3><i class="fa fa-user m-r-5"></i> Delete Invoices</h3>
                               </div>
                               <div class="modal-body">
                                  <div class="row">
                                     <div class="col-md-12">
                                        <form class="form-horizontal" action="update.php" method="post">
                                           <fieldset>
                                              <div class="col-md-12 form-group user-form-group">
                                                 <label class="control-label">Delete Entry</label>
                                                 <div class="pull-right">
                                                    <button type="button" class="btn btn-danger btn-sm">NO</button>
                                                    <button type="submit"  name="delete "class="btn btn-add btn-sm">YES</button>
                                                 </div>
                                              </div>
                                           </fieldset>
                                        </form>
                                     </div>
                                  </div>
                               </div>
                               <div class="modal-footer">
                                  <button type="button" class="btn btn-danger pull-left" data-dismiss="modal">Close</button>
                               </div>
                            </div>
                            <!-- /.modal-content -->
                         </div>
                         <!-- /.modal-dialog -->
                      </div>
                      <!-- /.modal -->
                   </section>
                   <!-- /.content -->
                </div>

              </div>
         <!-- /.content-wrapper -->
 <footer class="main-footer">
            <div class="pull-right hidden-xs"> <b>Version</b> 1.0</div>
            <strong>Copyright &copy; <a href="#"></a>.</strong> All rights reserved.
         </footer>
      </div>
      <!-- ./wrapper -->
      <!-- Start Core Plugins
         =====================================================================-->
      <!-- jQuery -->
      <script src="assets/plugins/jQuery/jquery-1.12.4.min.js" type="text/javascript"></script>
      <!-- jquery-ui --> 
      <script src="assets/plugins/jquery-ui-1.12.1/jquery-ui.min.js" type="text/javascript"></script>
      <!-- Bootstrap -->
      <script src="assets/bootstrap/js/bootstrap.min.js" type="text/javascript"></script>
      <!-- lobipanel -->
      <script src="assets/plugins/lobipanel/lobipanel.min.js" type="text/javascript"></script>
      <!-- Pace js -->
      <script src="assets/plugins/pace/pace.min.js" type="text/javascript"></script>
      <!-- SlimScroll -->
      <script src="assets/plugins/slimScroll/jquery.slimscroll.min.js" type="text/javascript"></script>
      <!-- FastClick -->
      <script src="assets/plugins/fastclick/fastclick.min.js" type="text/javascript"></script>
      <!-- CRMadmin frame -->
      <script src="assets/dist/js/custom.js" type="text/javascript"></script>
      <!-- End Core Plugins
         =====================================================================-->
      <!-- Start Theme label Script
         =====================================================================-->
      <!-- Dashboard js -->
      <script src="assets/dist/js/dashboard.js" type="text/javascript"></script>
      <!-- End Theme label Script
         =====================================================================-->
   </body>


</html>

