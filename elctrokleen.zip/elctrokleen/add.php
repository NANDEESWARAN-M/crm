<?php
 $conn = mysqli_connect("localhost","root","","electrokleen");
 error_reporting(0);
require_once('vendor\php-excel-reader\excel_reader2.php');
require_once('vendor\SpreadsheetReader.php');
$query1="SELECT * from notice";
$notice=$conn->query($query1);
if (isset($_POST["import"]))
{
    
    $allowedFileType = array("application/vnd.ms-excel", "text/xls", "text/xlsx");
 //  = ['application/vnd.ms-excel','text/xls','text/xlsx','application/vnd.openxmlformats-officedocument.spreadsheetml.sheet'];
  
 // if(in_array($_FILES["file"]["type"],$allowedFileType)){

        $targetPath = 'uploads/'.$_FILES['file']['name'];
        move_uploaded_file($_FILES['file']['tmp_name'], $targetPath);
        
        $Reader = new SpreadsheetReader($targetPath);
        
        $sheetCount = count($Reader->sheets());
        for($i=0;$i<$sheetCount;$i++)
        {
            
            $Reader->ChangeSheet($i);
            
            foreach ($Reader as $Row)
            {
          
                $datee = "";
                if(isset($Row[0])) {
                    $datee = mysqli_real_escape_string($conn,$Row[0]);
                }
                $machine_name = "";
                if(isset($Row[1])) {
                    $machine_name = mysqli_real_escape_string($conn,$Row[1]);
                }
                
                $linee = "";
                if(isset($Row[2])) {
                    $linee = mysqli_real_escape_string($conn,$Row[2]);
                }
                 $oil_type = "";
                if(isset($Row[3])) {
                    $oil_type = mysqli_real_escape_string($conn,$Row[3]);
                }
                $oil_grade = "";
                if(isset($Row[4])) {
                    $oil_grade = mysqli_real_escape_string($conn,$Row[4]);
                }                              
                 $oil_level = "";
                if(isset($Row[5])) {
                    $oil_level = mysqli_real_escape_string($conn,$Row[5]);
                }               
                
                if (!empty($datee) || !empty($machine_name)||!empty($linee)||!empty($oil_type)||!empty($oil_grade)||empty($oil_level)) {

          $query2="SELECT cost from oil where oil_grade= '".$oil_grade."' and oil_type= '".$oil_type."' ";
        $result1 = $conn->query($query2);
        $row=$result1->fetch_assoc();
        $costt =$oil_level* $row['cost'];
        $query3="update oil set end_stock=(end_stock-".$oil_level.")  where oil_grade= '".$oil_grade."' and oil_type= '".$oil_type."' ";
        $result2 = $conn->query($query3);
                  $query4 ="INSERT INTO full (datee,machine_name,linee,oil_type,oil_grade,oil_level,cost) values ('".$datee."','".$machine_name."','".$line."','".$oil_type."','".$oil_grade."',".$oil_level.",".$costt.")";                   
                     
                         $result3 = mysqli_query($conn, $query4);
                
                    if (($result3)) {
                        $type = "success";
                        $message = "Excel Data Imported into the Database";
                    } else {
                        $type = "error";
                        $message = "Problem in Importing Excel Data";
                       }
                }
             }
        
       }  
  /*}
  else
  { 
        $type = "error";
        $message = "Invalid File Type. Upload Excel File.";
  }*/
}

if(isset($_POST['datee']))
{
    $date = $_POST["datee"]; 

  $res = explode("/", $date);
$changedDate = $res[2]."-".$res[0]."-".$res[1];


      
      $machine = $_POST["machine_name"];
      $line = $_POST["line"];
      $oilgrade = $_POST["oil_grade"];
      $oillevel = $_POST["oil_level"];
      
      $oiltype = $_POST["oil_type"];
        
      
      
          $query5="SELECT cost from oil where oil_grade= '".$oilgrade."' and oil_type= '".$oiltype."' ";
        $result4= $conn->query($query5);
        $row=$result4->fetch_assoc();
        $cost =$oillevel* $row['cost'];
        
$query6="update oil set end_stock=end_stock-".$oil_level."  where oil_grade= '".$oilgrade."' and oil_type= '".$oiltype."' ";
        $result5 = $conn->query($query6);
      $query7 ="INSERT INTO full (datee,machine_name,linee,oil_type,oil_grade,oil_level,cost) values ('".$changedDate."','".$machine."','".$line."','".$oiltype."','".$oilgrade."','".$oillevel."','".$cost."')";
      $result6 = $conn->query($query7);
    if($result6)
    {
      echo '<script language="javascript">';
     echo 'alert("Data Added");';  
    echo '</script>';
     
      }
    else
    {
      echo '<script language="javascript">';
          echo 'alert("Error in adding data");';
           echo '</script>';
      
      
    }
    
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
      <meta charset="utf-8">
      <meta http-equiv="X-UA-Compatible" content="IE=edge">
      <meta name="viewport" content="width=device-width, initial-scale=1">
      <title>Electrokleen</title>
      <!-- Favicon and touch icons -->
      <link rel="shortcut icon" href="assets/dist/img/ico/favicon.png" type="image/x-icon">
      <!-- Start Global Mandatory Style
         =====================================================================-->
      <!-- jquery-ui css -->
      <link href="assets/plugins/jquery-ui-1.12.1/jquery-ui.min.css" rel="stylesheet" type="text/css"/>
      <!-- Bootstrap -->
      <link href="assets/bootstrap/css/bootstrap.min.css" rel="stylesheet" type="text/css"/>
      <!-- Bootstrap rtl -->
      <!--<link href="assets/bootstrap-rtl/bootstrap-rtl.min.css" rel="stylesheet" type="text/css"/>-->
      <!-- Lobipanel css -->
      <link href="assets/plugins/lobipanel/lobipanel.min.css" rel="stylesheet" type="text/css"/>
      <!-- Pace css -->
      <link href="assets/plugins/pace/flash.css" rel="stylesheet" type="text/css"/>
      <!-- Font Awesome -->
      <link href="assets/font-awesome/css/font-awesome.min.css" rel="stylesheet" type="text/css"/>
      <!-- Pe-icon -->
      <link href="assets/pe-icon-7-stroke/css/pe-icon-7-stroke.css" rel="stylesheet" type="text/css"/>
      <!-- Themify icons -->
      <link href="assets/themify-icons/themify-icons.css" rel="stylesheet" type="text/css"/>
      <!-- End Global Mandatory Style
         =====================================================================-->
      <!-- Start Theme Layout Style
         =====================================================================-->
      <!-- Theme style -->
      <link href="assets/dist/css/stylecrm.css" rel="stylesheet" type="text/css"/>
      <!-- Theme style rtl -->
      <!--<link href="assets/dist/css/stylecrm-rtl.css" rel="stylesheet" type="text/css"/>-->
      <!-- End Theme Layout Style
         =====================================================================-->
   </head>
   <body class="hold-transition sidebar-mini">
   <!--preloader-->
      <div id="preloader">
         <div id="status"></div>
      </div>
      <!-- Site wrapper -->
      <div class="wrapper">
         <header class="main-header">
            <a href="dashboard.php" class="logo">
               <!-- Logo -->
               <span class="logo-lg">
               <img src="assets/dist/img/logo.jpg" alt="">
               </span>
            </a>
            <!-- Header Navbar -->
            <nav class="navbar navbar-static-top">
               <a href="#" class="sidebar-toggle" data-toggle="offcanvas" role="button">
                  <!-- Sidebar toggle button-->
                  <span class="sr-only">Toggle navigation</span>
                  <span class="pe-7s-angle-left-circle"></span>
               </a>
               <div class="navbar-custom-menu">
                  <ul class="nav navbar-nav">
                     <!-- Orders -->
                     
                     <!-- Messages -->
                     
                     <!-- Notifications -->
                     <li class="dropdown notifications-menu">
                        <a href="#" class="dropdown-toggle" data-toggle="dropdown">
                        <i class="pe-7s-bell"></i>
                        <span class="label label-warning">7</span>
                        </a>
                        <ul class="dropdown-menu">
                           <li>
                              <ul class="menu">
                                 <?php

                                 while($row=$notice->fetch_assoc())
                                 {
                               
                                echo  "<li>";
                                 echo  "<a href=\"#\" class=\"border-gray\">";
                                   echo  "<i class=\"fa fa-dot-circle-o color-red\"></i>'".$row['message']."' </a>";
                                echo  "</li>";
                             }

                                 ?>
                              </ul>
                           </li>
                        </ul>
                     </li>
                     <!-- Tasks -->
                     <!-- Help -->
                     <!-- user -->
                     <li class="dropdown dropdown-user">
                        <a href="#" class="dropdown-toggle" data-toggle="dropdown">
                        <img src="assets/dist/img/avatar5.png" class="img-circle" width="45" height="45" alt="user"></a>
                        <ul class="dropdown-menu" >
                           
                           <li><a href="index.html">
                              <i class="fa fa-sign-out"></i> Signout</a>
                           </li>
                        </ul>
                     </li>
                  </ul>
               </div>
            </nav>
         </header>
         <!-- =============================================== -->
         <!-- Left side column. contains the sidebar -->
        <aside class="main-sidebar">
            <!-- sidebar -->
            <div class="sidebar">
               <!-- sidebar menu -->
               <ul class="sidebar-menu">
                  <li class="active">
                     <a href="dashboard.php"><i class="fa fa-tachometer"></i><span>Dashboard</span>
                     <span class="pull-right-container">
                     </span>
                     </a>
                  </li>
                  <li class="treeview">
                     <a href="#">
                     <i class="fa fa-list"></i><span>Add Consumption Details</span>
                     <span class="pull-right-container">
                     <i class="fa fa-angle-left pull-right"></i>
                     </span>
                     </a>
                     <ul class="treeview-menu">
                        <li><a href="add.php">Add Entry</a></li>
                        <li><a href="update.php">Update Entry</a></li>
                       <!--  <li><a href="delete.html">Delete Entry</a></li> -->
                     </ul>
                  </li>
                  
                  <li class="treeview">
                     <a href="#">
                     <i class="fa fa-bell"></i><span>Attendance</span>
                     <span class="pull-right-container">
                     <i class="fa fa-angle-left pull-right"></i>
                     </span>
                     </a>
                     <ul class="treeview-menu">
                        <li><a href="mark_at.php">Mark Attendance</a></li>
                        
                        <li><a href="at_report.php">Attendance Report</a></li>
                     </ul>
                  </li>
                 <li class="treeview">
                     <a href="#">
                     <i class="fa fa-bitbucket-square"></i><span>Stock</span>
                     <span class="pull-right-container">
                     <i class="fa fa-angle-left pull-right"></i>
                     </span>
                     </a>
                     <ul class="treeview-menu">
                        <li><a href="stockcost.php">Update Cost Details</a></li>
                        <li><a href="opening_stock.php">opening Stock</a></li>
                       

                        <li><a href="move_order.php">Move Order</a></li>
                        <li><a href="physical.php">physical_stock</a></li>
                         <li><a href="stock_report.php"> stock Report</a></li>
                     </ul>
                  </li>
                  <li class="treeview">
                     <a href="#">
                     <i class="fa fa-bar-chart"></i><span>Report</span>
                     <span class="pull-right-container">
                     <i class="fa fa-angle-left pull-right"></i>
                     </span>
                     </a>
                     <ul class="treeview-menu">
                         <li><a href='daily.php'><span>Daliy Report</span></a></li>
                          <li><a href='monthly.php'><span>Monthly Report</span></a></li>
                          <li><a href='weekly.php'><span>weekly Report</span></a></li>
                        
                             <li><a href='oilt.php'><span>Oil type Wise Report</span></a></li>
                           <li><a href='machine.php'><span>Machinary Report</span></a></li>
                          <li><a href='cost.php'><span>Cost Report</span></a></li>

                     </ul>
                  </li>
                  <li>
                     <a href="company.php">
                     <i class="fa fa-home"></i> <span>Companies</span>
                     <span class="pull-right-container">
                     </span>
                     </a>
                  </li>
                  <li>
                     <a href="machine_details.php">
                     <i class="glyphicon glyphicon-print"></i> <span>Manage Machine</span>
                     <span class="pull-right-container">
                     </span>
                     </a>
                  </li>
                  <li>
                     <a href="oil_details.php">
                     <i class="glyphicon glyphicon-tint"></i> <span>Manage Oil</span>
                     <span class="pull-right-container">
                     </span>
                     </a>
                  </li>
                  <li>
                     <a href="high.php">
                     <i class="fa fa-gear"></i> <span>Track High Consumption</span>
                     <span class="pull-right-container">
                     </span>
                     </a>
                  </li>
                  <li>
                     <a href="target.php">
                     <i class="fa fa-stop-circle"></i> <span>Set Targer</span>
                     <span class="pull-right-container">
                     </span>
                     </a>
                  </li>
                  

                  <li>
                     <a href="updatetemplevel.php">
                     <i class="fa fa-tachometer"></i> <span>Update Temperature/level</span>
                     <span class="pull-right-container">
                     </span>
                     </a>
                  </li>
               </ul>
            </div>
            <!-- /.sidebar -->
       </aside> <!-- =============================================== -->
        <!-- Content Wrapper. Contains page content -->
         <div class="content-wrapper">
            <!-- Content Header (Page header) -->
            <section class="content-header">
               <div class="header-icon">
                  <i class="glyphicon glyphicon-shopping-cart"></i>
               </div>
               <div class="header-title">
                  <h1>Add Consumption</h1>
                  <!-- <small></small> -->
               </div>
            </section>
            <!-- Main content -->
            
            <section class="content">
                <div class="row">
                   <div class="col-sm-4">
                      <div class="panel lobidisable panel-bd">
                         <div class="panel-heading">
                            <div class="panel-title">
                               <h4>Add Consumption</h4>
                            </div>
                         </div>
                         <div class="panel-body">
                         <h2>Import Excel File</h2>
    
    <div class="outer-container">
        <form  method="post"
            name="frmExcelImport" id="frmExcelImport" enctype="multipart/form-data" action="add.php">
            <div>
                <label>Choose Excel
                    File</br></br></label> <input type="file" name="file"
                    id="file" accept=".xls,.xlsx"></br>
</br>

                <button type="submit" id="submit" name="import"
                    class="btn btn-add">Import</button>
        
            </div>
        
        </form>
        
    </div>
    <div id="response" class="<?php if(!empty($type)) { echo $type . " display-block"; } ?>"><?php if(!empty($message)) { echo $message; } ?></div>
                           
                         </div>
                      </div>
                   </div>
                   <div class="col-sm-8">
                      <div class="panel lobidisable panel-bd">
                         <div class="panel-heading">
                            <div class="panel-title">
                               <h4>Add Consumption Details</h4>
                            </div>
                         </div>
                         <div class="panel-body">
                            <div class="table-responsive">
                                <form action="add.php" method="post">
                                    <div class="form-group">
                                        <label>Date</label>
                                        <div class=" input-group date form_date">
                                           <input id='minMaxExample' type="text" class="form-control years" name="datee"><span class="input-group-addon"><a href="#"><i class="fa fa-calendar"></i></a></span>
                                        </div>
                                     </div>
                                     <div class="form-group">
                                        <label>Machine Name</label>
                                        <select class="form-control" name="machine_name">
                                           <option>nakamura1</option>
                                           <option>nakamura2</option>
                                           <option>nakamura3</option>
                                           <option>nakamura4</option>
                                      
                                          
                                          
                                     </select>
                                     </div>
                                     <div class="form-group">
                                        <label>Enter line</label>
                                        <input type="text" class="form-control" name="line" placeholder="" required>
                                     </div>
                                   <div class="form-group">
                                      <label>Choose Oil Type</label>
                                      <select class="form-control" name="oil_type">
                                         <option>Lube</option>
                                         <option>Hydrallic</option>
                                        
                                        
                                   </select>
                                   </div>
                                   <div class="form-group">
                                      <label>Choose Oil Grade</label>
                                      <select class="form-control" name="oil_grade">
                                         <option>vga32</option>
                                         <option>vga46</option>
                                         <option>vga68</option>
                                         <option>vga156</option>
                                         <option>vga320</option>
                                        
                                        
                                   </select>
                                   </div>
                                  
                                   <div class="form-group">
                                      <label>Oil Consumption</label>
                                      <input type="text" class="form-control" name="oil_level" placeholder="In Liters" required>
                                   </div>
                                 
                                   <div class="form-group">
                                      <button type="submit" class="btn btn-add"><i class="fa fa-check">add</i> 
                                      </button>
                                   </div>
                                </form>
                            </div>
                         </div>
                      </div>
                   </div>
                </div>
            </div>
</div>
             </section>
             <!-- /.content -->
          

          <!-- /.content-wrapper -->
         <!-- /.content-wrapper -->
 <footer class="main-footer">
            <div class="pull-right hidden-xs"> <b>Version</b> 1.0</div>
            <strong>Copyright &copy; <a href="#"></a>.</strong> All rights reserved.
         </footer>
      </div>
      <!-- ./wrapper -->
      <!-- Start Core Plugins
         =====================================================================-->
      <!-- jQuery -->
      <script src="assets/plugins/jQuery/jquery-1.12.4.min.js" type="text/javascript"></script>
      <!-- jquery-ui --> 
      <script src="assets/plugins/jquery-ui-1.12.1/jquery-ui.min.js" type="text/javascript"></script>
      <!-- Bootstrap -->
      <script src="assets/bootstrap/js/bootstrap.min.js" type="text/javascript"></script>
      <!-- lobipanel -->
      <script src="assets/plugins/lobipanel/lobipanel.min.js" type="text/javascript"></script>
      <!-- Pace js -->
      <script src="assets/plugins/pace/pace.min.js" type="text/javascript"></script>
      <!-- SlimScroll -->
      <script src="assets/plugins/slimScroll/jquery.slimscroll.min.js" type="text/javascript"></script>
      <!-- FastClick -->
      <script src="assets/plugins/fastclick/fastclick.min.js" type="text/javascript"></script>
      <!-- CRMadmin frame -->
      <script src="assets/dist/js/custom.js" type="text/javascript"></script>
      <!-- End Core Plugins
         =====================================================================-->
      <!-- Start Theme label Script
         =====================================================================-->
      <!-- Dashboard js -->
      <script src="assets/dist/js/dashboard.js" type="text/javascript"></script>
      <!-- End Theme label Script
         =====================================================================-->
   </body>


</html>

