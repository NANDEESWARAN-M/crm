<?php
error_reporting(0);
session_start();
$conn=mysqli_connect("localhost","root","","electrokleen");
$todays_date=date("Y-m-d");
$this_month=date("F");
$todays_day=date("l");
$this_year=date("Y");
$query1="select sum(end_stock) as hydrallic from oil where oil_type='hydrallic' and status=1";
$temp=$conn->query($query1);
$row=$temp->fetch_assoc();
$hstock=$row['hydrallic'];
$query2="select sum(end_stock) as lube from oil where oil_type='lube' and status=1";
$temp=$conn->query($query2);
$row=$temp->fetch_assoc();
$lstock=$row['lube'];
$query3="SELECT count(*) from attendance where status=1 ";
$temp=$conn->query($query3);
$row=$temp->fetch_assoc();
$attendance=$row['count(*)'];
$query4 = "select usage_target as hydrallic ,(select usage_target from target where month='".$this_month."' and oil_type='lube') as lube from target where month='".$this_month."' and oil_type='hydrallic' ";
$temp=$conn->query($query4);
$row=$temp->fetch_assoc();
$htarget=$row['hydrallic'];
$ltarget=$row['lube'];
$query5="SELECT sum(cost) from full where monthname(datee)= '".$this_month."'";
$temp=$conn->query($query5);
$row=$temp->fetch_assoc();
$cost=$row['sum(cost)'];
$query6="SELECT count(machine_name) from machine where status=1";
$temp=$conn->query($query6);
$row=$temp->fetch_assoc();
$machine=$row['count(machine_name)'];
$query7="SELECT (sum(physical_stock)-sum(end_stock)) as hdev from oil where oil_type='hydrallic' and  status=1";
$temp=$conn->query($query7);
$row=$temp->fetch_assoc();
$hdev=$row['hdev'];
$query8="SELECT (sum(physical_stock)-sum(end_stock)) as ldev from oil where oil_type='lube' and  status=1";
$temp=$conn->query($query8);
$row=$temp->fetch_assoc();
$ldev=$row['ldev'];
$query9="create view hview as select monthname(datee)  as month,sum(oil_level) as hydrallic from full where oil_type='hydrallic' group by monthname(datee)";
$query10="create view lview as select monthname(datee)  as month,sum(oil_level) as lube from full where oil_type='lube' group by monthname(datee)";
$query11="select hview.month as month,hview.hydrallic as hydrallic ,lview.lube as lube from hview,lview where hview.month=lview.month";
$result11=$conn->query($query11);
$query12="SELECT oil_grade,(sum(opening_stock)-sum(end_stock)) as used from oil where oil_type='hydrallic' and status=1 group by oil_grade";
$result12=$conn->query($query12);
$query13="SELECT oil_grade,(sum(opening_stock)-sum(end_stock)) as used from oil where oil_type='lube' and status=1 group by oil_grade";
$result13=$conn->query($query13);
$query14="SELECT oil_grade,sum(end_stock) as actualstock,sum(physical_stock) as physicalstock ,(sum(end_stock)-sum(physical_stock))  as deviation from oil where oil_type='hydrallic'and  status=1 group by oil_grade";
$result14=$conn->query($query14);
$query15="SELECT oil_grade,sum(end_stock) as actualstock ,sum(physical_stock) as physicalstock,(sum(end_stock)-sum(physical_stock)) as deviation from oil where oil_type='lube' and status=1 group by oil_grade";
$result15=$conn->query($query15);
$query16="SELECT machine_name,oil_temp from full where oil_temp>120";
$result16=$conn->query($query16);
$query17="SELECT machine_name,oil_level,physical_level,(oil_level-physical_level) as loss from full where oil_level>1230";
$result17=$conn->query($query17);
$query18="SELECT * from notice";
$notice=$conn->query($query18);

?>



<!DOCTYPE html>
<html lang="en">
<head>
      <meta charset="utf-8">
      <meta http-equiv="X-UA-Compatible" content="IE=edge">
      <meta name="viewport" content="width=device-width, initial-scale=1">
      <title>Electrokleen</title>
      <!-- Favicon and touch icons -->
      <link rel="shortcut icon" href="assets/dist/img/ico/favicon.png" type="image/x-icon">
      <!-- Start Global Mandatory Style
         =====================================================================-->
      <!-- jquery-ui css -->
      <link href="assets/plugins/jquery-ui-1.12.1/jquery-ui.min.css" rel="stylesheet" type="text/css"/>
      <!-- Bootstrap -->
      <link href="assets/bootstrap/css/bootstrap.min.css" rel="stylesheet" type="text/css"/>
      <!-- Bootstrap rtl -->
      <!--<link href="assets/bootstrap-rtl/bootstrap-rtl.min.css" rel="stylesheet" type="text/css"/>-->
      <!-- Lobipanel css -->
      <link href="assets/plugins/lobipanel/lobipanel.min.css" rel="stylesheet" type="text/css"/>
      <!-- Pace css -->
      <link href="assets/plugins/pace/flash.css" rel="stylesheet" type="text/css"/>
      <!-- Font Awesome -->
      <link href="assets/font-awesome/css/font-awesome.min.css" rel="stylesheet" type="text/css"/>
      <!-- Pe-icon -->
      <link href="assets/pe-icon-7-stroke/css/pe-icon-7-stroke.css" rel="stylesheet" type="text/css"/>
      <!-- Themify icons -->
      <link href="assets/themify-icons/themify-icons.css" rel="stylesheet" type="text/css"/>
      <!-- End Global Mandatory Style
         =====================================================================-->
      <!-- Start Theme Layout Style
         =====================================================================-->
      <!-- Theme style -->
      <link href="assets/dist/css/stylecrm.css" rel="stylesheet" type="text/css"/>
      <!-- Theme style rtl -->
      <!--<link href="assets/dist/css/stylecrm-rtl.css" rel="stylesheet" type="text/css"/>-->
      <!-- End Theme Layout Style
         =====================================================================-->
      <script type="text/javascript" src="https://www.gstatic.com/charts/loader.js"></script>
    <script type="text/javascript">
      google.charts.load('current', {'packages':['corechart']});
      google.charts.load('current', {'packages':['gauge']});
	  google.charts.load('current', {'packages':['bar']});
	  google.charts.load('current', {'packages':['table']});
	  google.charts.setOnLoadCallback(drawTable1);
	  google.charts.setOnLoadCallback(drawTable2);
       google.charts.setOnLoadCallback(area);
       google.charts.setOnLoadCallback(hyradllicgauge);
      google.charts.setOnLoadCallback(lubegauge);
	   google.charts.setOnLoadCallback(bar1);
	    google.charts.setOnLoadCallback(bar2);
	    function drawTable1() {
        var data = new google.visualization.DataTable();
        data.addColumn('string', 'Machine Name');
        data.addColumn('number', 'Temperature');
        
        data.addRows([
        	<?php

              while($row=$result16->fetch_assoc())
              {


              	echo "['".$row['machine_name']."',".$row['oil_temp']."],";
              }


        	?>

        ]);

        var table = new google.visualization.Table(document.getElementById('table1'));

        table.draw(data, {showRowNumber: true, width: '100%', height: '100%'});
      }
       function drawTable2() {
        var data = new google.visualization.DataTable();
        data.addColumn('string', 'Machine Name');
        data.addColumn('number', 'Oil Level');
        data.addColumn('number', 'Physically measured Level');
        data.addColumn('number', 'loss/leak');
        
        data.addRows([
        	<?php

              while($row=$result17->fetch_assoc())
              {


              	echo "['".$row['machine_name']."',".$row['oil_level'].",".$row['physical_level'].",".$row['loss']."],";
              }


        	?>

        ]);

        var table = new google.visualization.Table(document.getElementById('table2'));

        table.draw(data, {showRowNumber: true, width: '100%', height: '100%'});
      }
	    function bar1() {
        var data = google.visualization.arrayToDataTable([
          ['oil_grade', 'actualstock', 'physicalstock', 'deviation'],
          <?php

          while($row=$result14->fetch_assoc())
          {

          	echo "['".$row['oil_grade']."',".$row['actualstock'].",".$row['physicalstock'].",".$row['deviation']."],";
          }


          ?>
          
        ]);

        var options = {
          chart: {
            title: 'Devitaion',
            subtitle: '',
          },
          bars: 'vertical' // Required for Material Bar Charts.
        };

        var chart = new google.charts.Bar(document.getElementById('bar1'));

        chart.draw(data, google.charts.Bar.convertOptions(options));
      }
	   function bar2() {
        var data = google.visualization.arrayToDataTable([
          ['oil_grade', 'actualstock', 'physicalstock', 'deviation'],
          <?php

          while($row=$result15->fetch_assoc())
          {

          		echo "['".$row['oil_grade']."',".$row['actualstock'].",".$row['physicalstock'].",".$row['deviation']."],";
          }


          ?>
          
        ]);

        var options = {
          chart: {
            title: 'Devitaion',
            subtitle: '',
          },
          bars: 'vertical' // Required for Material Bar Charts.
        };

        var chart = new google.charts.Bar(document.getElementById('bar2'));

        chart.draw(data, google.charts.Bar.convertOptions(options));
      }
	  
        function area() {
        var data = google.visualization.arrayToDataTable([
          ['Month', 'Hydralic Oil', 'Lube Oil'],
        
          <?php

          while($row=$result11->fetch_assoc())
          {

          	echo "['".$row['month']."',".$row['hydrallic'].",".$row['lube']."],";
          }


          ?>
          
        ]);

        var options = {
          title: 'Year Consumption',
          hAxis: {title: 'Month',  titleTextStyle: {color: '#333'}},
          vAxis: {minValue: 0}
        };

        var chart = new google.visualization.AreaChart(document.getElementById('area'));
        chart.draw(data, options);
      }

      function hyradllicgauge() {

        var data = google.visualization.arrayToDataTable([
          ['Label', 'Value'],
          
          <?php

          while($row=$result12->fetch_assoc())
          {

          	echo "['".$row['oil_grade']."',".$row['used']."],";
          }


          ?>
        ]);

        var options = {
          width: 500, height: 250,
          redFrom: 900, redTo: 1000,
          yellowFrom:750, yellowTo: 900,
          min:0,max:1000,
          minorTicks: 5
        };

        var chart = new google.visualization.Gauge(document.getElementById('hyradllicgauge'));

        chart.draw(data, options);

        /*setInterval(function() {
          data.setValue(0, 1, 40 + 45);
          chart.draw(data, options);
        }, 13000);
        setInterval(function() {
          data.setValue(1, 1, 40 + Math.round(60 * Math.random()));
          chart.draw(data, options);
        }, 5000);
        setInterval(function() {
          data.setValue(2, 1, 60 + Math.round(20 * Math.random()));
          chart.draw(data, options);
        }, 26000);*/
      }

function lubegauge() {

        var data = google.visualization.arrayToDataTable([
          ['Label', 'Value'],
          <?php

          while($row=$result13->fetch_assoc())
          {

          	echo "['".$row['oil_grade']."',".$row['used']."],";
          }


          ?>
        ]);

        var options = {
          width: 500, height: 250,
          redFrom: 900, redTo: 1000,
          yellowFrom:750, yellowTo: 900,
          min:0,max:1000,
          minorTicks: 5
        };

        var chart = new google.visualization.Gauge(document.getElementById('lubegauge'));

        chart.draw(data, options);

       /* setInterval(function() {
          data.setValue(0, 1, 40 + Math.round(60 * Math.random()));
          chart.draw(data, options);
        }, 13000);
        setInterval(function() {
          data.setValue(1, 1, 40 + Math.round(60 * Math.random()));
          chart.draw(data, options);
        }, 5000);
        setInterval(function() {
          data.setValue(2, 1, 60 + Math.round(20 * Math.random()));
          chart.draw(data, options);
        }, 26000);*/
      }


    </script>
   
   </head>
   <body class="hold-transition sidebar-mini">
   <!--preloader-->
      <div id="preloader">
         <div id="status"></div>
      </div>
      <!-- Site wrapper -->
      <div class="wrapper">
         <header class="main-header">
            <a href="dashboard.php" class="logo">
               <!-- Logo -->
               <span class="logo-lg">
               <img src="assets/dist/img/logo.jpg" alt="">
               </span>
            </a>
            <!-- Header Navbar -->
            <nav class="navbar navbar-static-top">
               <a href="#" class="sidebar-toggle" data-toggle="offcanvas" role="button">
                  <!-- Sidebar toggle button-->
                  <span class="sr-only">Toggle navigation</span>
                  <span class="pe-7s-angle-left-circle"></span>
               </a>
               <div class="navbar-custom-menu">
                  <ul class="nav navbar-nav">
                     <!-- Orders -->
                     
                     <!-- Messages -->
                     
                     <!-- Notifications -->
                     <li class="dropdown notifications-menu">
                        <a href="#" class="dropdown-toggle" data-toggle="dropdown">
                        <i class="pe-7s-bell"></i>
                        <span class="label label-warning">7</span>
                        </a>
                        <ul class="dropdown-menu">
                           <li>
                              <ul class="menu">
                              	<?php

                                 while($row=$notice->fetch_assoc())
                                 {
                               
                                echo  "<li>";
                                 echo  "<a href=\"#\" class=\"border-gray\">";
                                   echo  "<i class=\"fa fa-dot-circle-o color-red\"></i>'".$row['message']."' </a>";
                                echo  "</li>";
                             }

                                 ?>
                                <!--  <li><a href="#" class="border-gray">
                                    <i class="fa fa-dot-circle-o color-yellow"></i>
                                    Add more admin...</a>
                                 </li>
                                 <li><a href="#" class="border-gray">
                                    <i class="fa fa-dot-circle-o color-violet"></i> Add more clients and order</a>
                                 </li>
                                 <li><a href="#" class="border-gray">
                                    <i class="fa fa-dot-circle-o color-yellow"></i>
                                    Add more admin...</a>
                                 </li>
                                 <li><a href="#" class="border-gray">
                                    <i class="fa fa-dot-circle-o color-violet"></i> Add more clients and order</a>
                                 </li> -->
                              </ul>
                           </li>
                        </ul>
                     </li>
                     <!-- Tasks -->
                     <!-- Help -->
                     <!-- user -->
                     <li class="dropdown dropdown-user">
                        <a href="#" class="dropdown-toggle" data-toggle="dropdown">
                        <img src="assets/dist/img/avatar5.png" class="img-circle" width="45" height="45" alt="user"></a>
                        <ul class="dropdown-menu" >
                           
                           <li><a href="index.html">
                              <i class="fa fa-sign-out"></i> Signout</a>
                           </li>
                        </ul>
                     </li>
                  </ul>
               </div>
            </nav>
         </header>
         <!-- =============================================== -->
         <!-- Left side column. contains the sidebar -->
         <aside class="main-sidebar">
            <!-- sidebar -->
            <div class="sidebar">
               <!-- sidebar menu -->
               <ul class="sidebar-menu">
                  <li class="active">
                     <a href="dashboard.php"><i class="fa fa-tachometer"></i><span>Dashboard</span>
                     <span class="pull-right-container">
                     </span>
                     </a>
                  </li>
                  <li class="treeview">
                     <a href="#">
                     <i class="fa fa-list"></i><span>Add Consumption Details</span>
                     <span class="pull-right-container">
                     <i class="fa fa-angle-left pull-right"></i>
                     </span>
                     </a>
                     <ul class="treeview-menu">
                        <li><a href="add.php">Add Entry</a></li>
                        <li><a href="update.php">Update Entry</a></li>
                       <!--  <li><a href="delete.html">Delete Entry</a></li> -->
                     </ul>
                  </li>
                  
                  <li class="treeview">
                     <a href="#">
                     <i class="fa fa-bell"></i><span>Attendance</span>
                     <span class="pull-right-container">
                     <i class="fa fa-angle-left pull-right"></i>
                     </span>
                     </a>
                     <ul class="treeview-menu">
                        <li><a href="mark_at.php">Mark Attendance</a></li>
                        
                        <li><a href="at_report.php">Attendance Report</a></li>
                     </ul>
                  </li>
                 <li class="treeview">
                     <a href="#">
                     <i class="fa fa-bitbucket-square"></i><span>Stock</span>
                     <span class="pull-right-container">
                     <i class="fa fa-angle-left pull-right"></i>
                     </span>
                     </a>
                     <ul class="treeview-menu">
                        <li><a href="stockcost.php">Update Cost Details</a></li>
                        <li><a href="opening_stock.php">opening Stock</a></li>
                       

                        <li><a href="move_order.php">Move Order</a></li>
                        <li><a href="physical.php">physical_stock</a></li>
                         <li><a href="stock_report.php"> stock Report</a></li>
                     </ul>
                  </li>
                  <li class="treeview">
                     <a href="#">
                     <i class="fa fa-bar-chart"></i><span>Report</span>
                     <span class="pull-right-container">
                     <i class="fa fa-angle-left pull-right"></i>
                     </span>
                     </a>
                     <ul class="treeview-menu">
                         <li><a href='daily.php'><span>Daliy Report</span></a></li>
                          <li><a href='monthly.php'><span>Monthly Report</span></a></li>
                          <li><a href='weekly.php'><span>weekly Report</span></a></li>
                        
                             <li><a href='oilt.php'><span>Oil type Wise Report</span></a></li>
                           <li><a href='machine.php'><span>Machinary Report</span></a></li>
                          <li><a href='cost.php'><span>Cost Report</span></a></li>

                     </ul>
                  </li>
                  <li>
                     <a href="company.php">
                     <i class="fa fa-home"></i> <span>Companies</span>
                     <span class="pull-right-container">
                     </span>
                     </a>
                  </li>
                  <li>
                     <a href="machine_details.php">
                     <i class="glyphicon glyphicon-print"></i> <span>Manage Machine</span>
                     <span class="pull-right-container">
                     </span>
                     </a>
                  </li>
                  <li>
                     <a href="oil_details.php">
                     <i class="glyphicon glyphicon-tint"></i> <span>Manage Oil</span>
                     <span class="pull-right-container">
                     </span>
                     </a>
                  </li>
                  <li>
                     <a href="high.php">
                     <i class="fa fa-gear"></i> <span>Track High Consumption</span>
                     <span class="pull-right-container">
                     </span>
                     </a>
                  </li>
                  <li>
                     <a href="target.php">
                     <i class="fa fa-stop-circle"></i> <span>Set Targer</span>
                     <span class="pull-right-container">
                     </span>
                     </a>
                  </li>
                  

                  <li>
                     <a href="updatetemplevel.php">
                     <i class="fa fa-tachometer"></i> <span>Update Temperature/level</span>
                     <span class="pull-right-container">
                     </span>
                     </a>
                  </li>
               </ul>
            </div>
            <!-- /.sidebar -->
       </aside>
         <!-- =============================================== -->
         <!-- Content Wrapper. Contains page content -->
         <div class="content-wrapper">
            <!-- Content Header (Page header) -->
            <section class="content-header">
               <div class="header-icon">
                  <i class="fa fa-dashboard"></i>
               </div>
               <div class="header-title">
                  <h1>Dashboard</h1>
                  <small>An Overview</small>
               </div>
            </section>
            <!-- Main content -->
            <section class="content">
               <div class="row">
                  <div class="col-xs-12 col-sm-6 col-md-6 col-lg-3">
                     <div id="cardbox1">
                        <div class="statistic-box">
                           <i class="glyphicon glyphicon-shopping-cart"></i>
                           <div class="counter-number pull-right">
                              <span class="count-number"><?php  echo $hstock;  ?></span> 
                              <span class="slight"><i class="fa fa-play fa-rotate-270"> </i>
                              </span>
                           </div>
                           <a href="stock_report.php">
                           <h3>Hydralic Oil Stock</h3>
                         </a>
                        </div>
                 </div>
                  </div>
                    <div class="col-xs-12 col-sm-6 col-md-6 col-lg-3">
                     <div id="cardbox3">
                        <div class="statistic-box">
                           <i class="glyphicon glyphicon-shopping-cart"></i>
                           <div class="counter-number pull-right">
                              <i class="count-number"></i><span class="count-number"><?php  echo $lstock;  ?></span> 
                              <span class="slight"><i class="fa fa-play fa-rotate-270"> </i>
                              </span>
                           </div>
                           <a href="stock_report.php">
                           <h3>Lube Oil Stock</h3>
                         </a>
                        </div>
                     </div>
                  </div>
                
                  <div class="col-xs-12 col-sm-6 col-md-6 col-lg-3">
                     <div id="cardbox2">
                        <div class="statistic-box">
                           <i class="fa fa-user-secret fa-3x"></i>
                           <div class="counter-number pull-right">
                              <span class="count-number"><?php  echo $attendance;  ?></span> 
                              <span class="slight"><i class="fa fa-play fa-rotate-270"> </i>
                              </span>
                           </div>
                           <a href="attendance.php">
                           <h3>Today's Attendance</h3>
                         </a>
                        </div>
                     </div>
                  </div>

                  <div class="col-xs-12 col-sm-6 col-md-6 col-lg-3">
                     <div id="cardbox3">
                        <div class="statistic-box">
                           <!-- <i class="fa fa-money fa-3x"></i> -->
                           <div class="counter-number pull-right">
                            <!--   <i class="ti ti-money"></i> --><span class="count-number"><?php  echo $htarget."(hyd)/".$ltarget."(lub)";  ?></span> 

                              <span class="slight"><i class="fa fa-play fa-rotate-270"> </i>
                              </span>
                           </div>
                           <a href="target.php">
                           <h3>This Month Target</h3>
                         </a>
                        </div>
                     </div>
                  </div>
                  <div class="col-xs-12 col-sm-6 col-md-6 col-lg-3">
                     <div id="cardbox4">
                        <div class="statistic-box">
                           <i class="fa fa-money fa-3x"></i>
                           <div class="counter-number pull-right">
                              <i class="ti ti-money"></i><span class="count-number"><?php  echo $cost;  ?></span> 
                              <span class="slight"><i class="fa fa-play fa-rotate-270"> </i>
                              </span>
                           </div>
                           <a href="cost.php">
                           <h3>Month Total Expense</h3>
                         </a>
                        </div>
                     </div>
                  </div>
                <div class="col-xs-12 col-sm-6 col-md-6 col-lg-3">
                     <div id="cardbox2">
                        <div class="statistic-box">
                           <i class="glyphicon glyphicon-print"></i>
                           <div class="counter-number pull-right">
                              <span class="count-number"><?php  echo $machine;  ?></span> 
                              <span class="slight"><i class="fa fa-play fa-rotate-270"> </i>
                              </span>
                           </div>
                           <a href="machine_details.php">
                           <h3>Total no.of Machine</h3>
                         </a>
                        </div>
                     </div>
                  </div>
                <div class="col-xs-12 col-sm-6 col-md-6 col-lg-3">
                     <div id="cardbox2">
                        <div class="statistic-box">
                           <i class="hvr-buzz-out fa fa-line-chart"></i>
                           <div class="counter-number pull-right">
                              <span class="count-number"><?php  echo $hdev;  ?></span> 
                              <span class="slight"><i class="fa fa-play fa-rotate-270"> </i>
                              </span>
                           </div>
                           <a href="oilt.php">
                           <h3>Hydrallic Oil Devitation</h3>
                         </a>
                        </div>
                     </div>
                  </div>
               <div class="col-xs-12 col-sm-6 col-md-6 col-lg-3">
                     <div id="cardbox2">
                        <div class="statistic-box">
                           <i class="hvr-buzz-out fa fa-line-chart"></i>
                           <div class="counter-number pull-right">
                              <span class="count-number"><?php  echo $ldev;  ?></span> 
                              <span class="slight"><i class="fa fa-play fa-rotate-270"> </i>
                              </span>
                           </div>
                           <a href="oilt.php">
              
                           <h3>lube Oil Devitation</h3>
                         </a>
                        </div>
                     </div>
                  </div>
               </div>
               <div class="row">
                  <div class="col-sm-12">
                     <div class="panel panel-bd lobidrag">
                        <div class="panel-heading">
                           <div class="panel-title">
                              <h4>Year Oil Consumption Report</h4>
                           </div>
                        </div>
                        <div class="panel-body">
                          <div class="panel-body"><div id="area" style="width: 1000px; height: 350px;"></div>
                        </div>
                     </div>
                   </div>
                 </div>
                  <!-- Flot Ber Chart -->
                  <div class="col-sm-12 col-md-6">
                     <div class="panel panel-bd lobidrag">
                        <div class="panel-heading">
                           <div class="panel-title">
                              <h4>Hydralic Oil Consumption</h4>
                           </div>
                        </div>
                        <div class="panel-body"><div id="hyradllicgauge" style="width: 450px; height: 200px;"></div>
                        </div>
                     </div>
                  </div>
                  <!-- Flot Points Chart -->
                  <div class="col-sm-12 col-md-6">
                     <div class="panel panel-bd lobidrag">
                        <div class="panel-heading">
                           <div class="panel-title">
                              <h4>Lube Oil Consumption</h4>
                           </div>
                        </div>
                        <div class="panel-body"><div id="lubegauge" style="width: 450px; height: 200px;"></div>
                        </div>
                     </div>
                  </div>
                  <!-- Flot Line Chart -->
                  <!-- <div class="col-sm-12 col-md-6">
                     <div class="panel panel-bd lobidrag">
                        <div class="panel-heading">
                           <div class="panel-title">
                              <h4>Year Consumption Report</h4>
                           </div>
                        </div>
                        <div class="panel-body">
                           <div class="panel-body"><div id="chart_div2" style="width: 600px; height: 200px;"></div>
                        </div>
                     </div>
                  </div>
               </div> -->
                  <!-- Flot Real Time Chart -->
                 <!--  <div class="col-sm-12 col-md-6">
                     <div class="panel panel-bd lobidrag">
                        <div class="panel-heading">
                           <div class="panel-title">
                              <h4>Real time chart</h4>
                           </div>
                        </div>
                        <div class="panel-body">
                           <div class="flotChart">
                              <div id="flotChart4" class="flotChart-demo"></div>
                           </div>
                        </div>
                     </div>
                  </div> -->
                  <!-- Flot Filled Area Chart -->
                  <div class="col-sm-12 col-md-6">
                     <div class="panel panel-bd lobidrag">
                        <div class="panel-heading">
                           <div class="panel-title">
                              <h4>Devitaion in  Hydralic Stock</h4>
                           </div>
                        </div>
                        <div class="panel-body">
                         <div id="bar1" style="width: 500px; height: 300px;"></div> 
                        </div>
                     </div>
                  </div>
                  <!-- Flot Line Chart With Steps -->
                  <div class="col-sm-12 col-md-6">
                     <div class="panel panel-bd lobidrag">
                        <div class="panel-heading">
                           <div class="panel-title">
                              <h4>Devitaion in  Hydralic Stock</h4>
                           </div>
                        </div>
                        <div class="panel-body">
                          <div id="bar2" style="width: 500px; height: 300px;"></div> 
                        </div>
                     </div>
                  </div>
                  <!-- Flot Line With Points Chart -->
                 <!--  <div class="col-sm-12 col-md-8">
                     <div class="panel panel-bd lobidrag">
                        <div class="panel-heading">
                           <div class="panel-title">
                              <h4>Line with points</h4>
                           </div>
                        </div>
                        <div class="panel-body">
                           <div class="flotChart">
                              <div id="flotChart7" class="flotChart-demo"></div>
                           </div>
                        </div>
                     </div>
                  </div>
                  Flot Pie Chart
                  <div class="col-sm-12 col-md-4">
                     <div class="panel panel-bd lobidisable">
                        <div class="panel-heading">
                           <div class="panel-title">
                              <h4>Pie chart </h4>
                           </div>
                        </div>
                        <div class="panel-body">
                           <div class="flotChart">
                              <div id="flotChart8" class="flotChart-demo"></div>
                           </div>
                        </div>
                     </div>
                  </div>
               </div> -->
                <div class="row">
                  
                  <div class="col-xs-12 col-sm-6 col-md-6 col-lg-6">
                     <div class="panel panel-bd lobidisable">
                        <div class="panel-heading">
                           <div class="panel-title">
                              <h4>Oil Temperature</h4>
                           </div>
                        </div>
                        <div class="panel-body">
                        	
                        	<div id="table1"></div>
                     </div>
                     </div>
                  </div>
                    <div class="col-xs-12 col-sm-6 col-md-6 col-lg-6">
                     <div class="panel panel-bd lobidisable">
                        <div class="panel-heading">
                           <div class="panel-title">
                              <h4>oil level</h4>
                           </div>
                        </div>
                        <div class="panel-body">
                          <div id="table2"></div>
                        </div>
                     </div>
                  </div>
               </div>
              
               <!-- /.row -->
               <!-- <div class="row">
                  <div class="col-xs-12 col-sm-8">
                     <div class="panel panel-bd lobidrag">
                        <div class="panel-heading">
                           <div class="panel-title">
                              <h4>Google Map</h4>
                           </div>
                        </div>
                        <div class="panel-body">
                           <div class="google-maps">
                              <iframe src="https://maps.google.co.uk/maps?f=q&amp;source=s_q&amp;hl=en&amp;geocode=&amp;q=15+Springfield+Way,+Hythe,+CT21+5SH&amp;aq=t&amp;sll=52.8382,-2.327815&amp;sspn=8.047465,13.666992&amp;ie=UTF8&amp;hq=&amp;hnear=15+Springfield+Way,+Hythe+CT21+5SH,+United+Kingdom&amp;t=m&amp;z=14&amp;ll=51.077429,1.121722&amp;output=embed"></iframe>
                           </div>
                        </div>
                     </div>
                  </div>
                  <div class="col-xs-12 col-sm-4">
                     <div class="panel panel-bd lobidrag">
                        <div class="panel-heading">
                           <div class="panel-title">
                              <h4>Calender</h4>
                           </div>
                        </div>
                        <!- Monthly calender widget -->
                        <div class="panel panel-bd">
                           <div class="panel-body">
                              <div class="monthly_calender">
                                 <div class="monthly" id="m_calendar"></div>
                              </div>
                           </div>
                        </div>
                     </div>
                  </div>
               </div> -->
            </section>
            <!-- /.content -->
         </div>
         <!-- /.content-wrapper -->
         <footer class="main-footer">
            <div class="pull-right hidden-xs"> <b>Version</b> 1.0</div>
            <strong>Copyright &copy; <a href="#"></a>.</strong> All rights reserved.
         </footer>
      </div>
      <!-- ./wrapper -->
      <!-- Start Core Plugins
         =====================================================================-->
      <!-- jQuery -->
      <script src="assets/plugins/jQuery/jquery-1.12.4.min.js" type="text/javascript"></script>
      <!-- jquery-ui --> 
      <script src="assets/plugins/jquery-ui-1.12.1/jquery-ui.min.js" type="text/javascript"></script>
      <!-- Bootstrap -->
      <script src="assets/bootstrap/js/bootstrap.min.js" type="text/javascript"></script>
      <!-- lobipanel -->
      <script src="assets/plugins/lobipanel/lobipanel.min.js" type="text/javascript"></script>
      <!-- Pace js -->
      <script src="assets/plugins/pace/pace.min.js" type="text/javascript"></script>
      <!-- SlimScroll -->
      <script src="assets/plugins/slimScroll/jquery.slimscroll.min.js" type="text/javascript"></script>
      <!-- FastClick -->
      <script src="assets/plugins/fastclick/fastclick.min.js" type="text/javascript"></script>
      <!-- CRMadmin frame -->
      <script src="assets/dist/js/custom.js" type="text/javascript"></script>
      <!-- End Core Plugins
         =====================================================================-->
      <!-- Start Theme label Script
         =====================================================================-->
      <!-- Dashboard js -->
      <script src="assets/dist/js/dashboard.js" type="text/javascript"></script>
      <!-- End Theme label Script
         =====================================================================-->
   </body>


</html>

