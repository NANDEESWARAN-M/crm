<html>
<head>
<?php
error_reporting(0);
session_start();
$conn=mysqli_connect("localhost","root","","electrokleen");
$query="select  user_name,password from admin";
$result=$conn->query($query);
$flag=0;


while($row=$result->fetch_assoc())
{
	if(($row['user_name']==$_POST["username"])&&($row['password']==$_POST["password"]))
	{
     $flag=1;

	}

}
if($flag)
{

	include "dashboard.php";
	
}
else
{
	echo '<script language="javascript">';
  echo 'alert("Acess denied");'; 
  echo '</script>';
  include "index.php";
 
}
?>
</head>
<body>
</body>
</html>